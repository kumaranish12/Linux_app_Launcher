export interface App {
	name: string;
	icon: string;
	exec: string;
}
