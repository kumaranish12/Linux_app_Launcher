<script lang="ts">
    import Time from "./components/Time.svelte";
    import Launcher from "./components/Launcher.svelte";
    import { tick } from "svelte";

    let s: boolean = $state(true);
    let filter: string = $state("");
    let inputEl: HTMLInputElement | null = null;
    

    window.toggle = async () => {
        if (s) {
            // Showing launcher
            s = !s;
            await tick();
            
            if (inputEl) {
                inputEl.focus();
            }
            
            window.weld({
                type: "configureGTKLayerShell",
                config_layer: {
                    layer: "overlay",
                },
            });
            window.weld({
                type: "configureFocus",
                focus: "exclusive",
            });
        } else {
            // Hiding launcher
            filter = "zzzzzzzzzzzzzzzzzzz";
            if (inputEl) {
                inputEl.blur(); // Explicitly blur the input
            }
            
            setTimeout(() => {
                s = !s;
                filter = "";
                
                window.weld({
                    type: "configureGTKLayerShell",
                    config_layer: {
                        layer: "bottom",
                    },
                });
                window.weld({
                    type: "configureFocus",
                    focus: "none",
                });
            }, 700);
        }
    };
</script>

{#if s}
    <Time />
{/if}

{#if !s}
    <input
        bind:this={inputEl}
        type="text"
        bind:value={filter}
        placeholder="Filter..."
        style="position: absolute; top: 50px; left: 10px;"
    />
    <Launcher {filter} />
{/if}

<style>
    input {
        opacity: 0;
    }
    button {
        position: absolute;
        top: 10px;
        left: 10px;
        background-color: #eafafb;
        border: none;
        padding: 10px 20px;
        border-radius: 5px;
        cursor: pointer;
        font-size: 16px;
    }
    button:hover {
        background-color: #d1e3f8;
    }
</style>
