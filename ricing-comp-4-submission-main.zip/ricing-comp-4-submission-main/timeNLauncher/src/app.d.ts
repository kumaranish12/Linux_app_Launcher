declare global {
	interface Window {
		toggle: () => void;
	}
}
