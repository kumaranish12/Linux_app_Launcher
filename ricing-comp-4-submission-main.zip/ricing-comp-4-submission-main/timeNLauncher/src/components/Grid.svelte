<script lang="ts">
    export let hexagonSide: number = 50;
    let hexagonHeight = (Math.sqrt(3) * hexagonSide) / 2;
    import Hexagon from "./Hexagon.svelte";
    import type { App } from "../types";
    export let apps: App[] = [];
    export let filter: string = "";

    export let grid: number[][] = [
        [0, 1, 1, 1, 0],
        [1, 1, 1, 1, 1],
        [1, 1, 0, 1, 1],
        [1, 1, 0, 1, 1],
        [1, 1, 0, 1, 1],
        [1, 1, 0, 1, 1],
        [1, 1, 0, 1, 1],
        [1, 1, 1, 1, 1],
        [0, 0, 1, 0, 0],
    ];
    function GridSize() {
        const rows = grid.length;
        const cols = grid[0].length;
        const width = ((3 * cols + 1) / 2) * hexagonSide;
        const height = (2 * rows + 1) * hexagonHeight;
        return { width, height };
    }
    function getIndex(row: number, col: number): number {
        let index = 0;
        for (let i = 0; i <= row; i++) {
            for (let j = 0; j < grid[i].length; j++) {
                if (grid[i][j] === 1) {
                    // stop counting when we reach the current cell
                    if (i === row && j === col) return index;
                    index++;
                }
            }
        }
        // if (index > 50) {
        //     alert(`row: ${row}, col: ${col}`);
        //     alert(index);
        // }
        return index;
    }
</script>

<div
    class="grid"
    style="width: {GridSize().width}px; height: {GridSize().height}px;"
>
    {#each grid as row, rowIndex}
        {#each row as cell, cellIndex (`${rowIndex}-${cellIndex}-${cell}`)}
            <Hexagon
                x={(3 * cellIndex * hexagonSide) / 2}
                y={rowIndex * 2 * hexagonHeight +
                    (cellIndex % 2 ? hexagonHeight : 0)}
                {hexagonSide}
                app={apps[getIndex(rowIndex, cellIndex)]}
                render={cell}
                filtered={apps[getIndex(rowIndex, cellIndex)] &&
                    apps[getIndex(rowIndex, cellIndex)].name
                        .toLowerCase()
                        .includes(filter.toLowerCase())}
                {rowIndex}
                colIndex={cellIndex}
                totalCols={grid[0].length}
                totalRows={grid.length}
            ></Hexagon>
        {/each}
    {/each}
</div>

<style>
    .grid {
        position: relative;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
    }
</style>
