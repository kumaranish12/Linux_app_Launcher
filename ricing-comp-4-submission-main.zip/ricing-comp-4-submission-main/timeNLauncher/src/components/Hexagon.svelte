<script lang="ts">
    import { onMount } from "svelte";
    import type { App } from "../types";
    const {
        app,
        rowIndex,
        colIndex,
        render = 1,
        hexagonSide = 500,
        x = 60,
        y = 60,
        filtered = false,
        totalRows,
        totalCols,
    } = $props<{
        app: App | undefined;
        render: number;
        hexagonSide: number;
        x: number;
        y: number;
        rowIndex: number;
        colIndex: number;
        filtered: boolean;
        totalRows: number;
        totalCols: number;
    }>();
    import { Tween } from "svelte/motion";
    import { linear, cubicInOut } from "svelte/easing";

    const centerRow = totalRows / 2;
    const centerCol = totalCols / 2;
    const maxDist = Math.hypot(centerRow, centerCol); // max distance from center

    const dist = Math.hypot(rowIndex - centerRow, colIndex - centerCol);
    let delay = (maxDist - dist) * 100;

    let rx = new Tween(30, {
        duration: 0,
        delay: delay,
    });
    let ry = new Tween(30, {
        duration: 0,
        delay: delay,
    });
    $effect(() => {
        if (filtered && render) {
            setTimeout(() => {
                rx.set(0);
                ry.set(0);
            }, delay);
        } else {
            setTimeout(() => {
                rx.set(Math.ceil(Math.random() > 0.5 ? -90 : 90));
                ry.set(Math.ceil(Math.random() > 0.5 ? -90 : 90));
            }, delay);
        }
    });

    onMount(() => {
        rx.set(Math.random() > 0.5 ? -90 : 90);
        ry.set(Math.random() > 0.5 ? -90 : 90);
        setTimeout(() => {
            requestAnimationFrame(() => {
                rx.set(0);
                ry.set(0);
            });
        }, delay);
    });

    function handleClick() {
        if (app?.exec) {
            window.weld({
                type: "exec",
                script: app.exec,
            });
        }
        window.toggle();
    }
</script>

{#if render}
    <div
        class="hexagon"
        style="width: {2 *
            hexagonSide}px; top: {y}px; left: {x}px; position: absolute; --sidelength: {hexagonSide}; transform: rotateX({rx.current}deg) rotateY({ry.current}deg);"
        on:click={handleClick}
        title={app?.name}
    >
        <div class="content-wrapper">
            {#if app}
                <img
                    src={"file://" + app.icon}
                    alt={app.name}
                    style="
                width: 64px;
                height: 64px;
                object-fit: contain;
                padding: 4px;
              "
                    draggable="false"
                />
            {:else}
                <slot />
            {/if}
        </div>

        <!-- border divs unchanged -->
        <div
            class="border"
            style="width: {hexagonSide}px; transform: translateX(50%);"
        ></div>
        <div
            class="border"
            style="width: {hexagonSide}px; transform: translateX({hexagonSide}px) rotate(60deg) translateX(50%);"
        ></div>
        <div
            class="border"
            style="width: {hexagonSide}px; transform: rotate(-60deg) translateX(-50%);"
        ></div>
        <div
            class="border"
            style="width: {hexagonSide}px; bottom: 0; transform: rotate(60deg) translateX(-50%);"
        ></div>
        <div
            class="border"
            style="width: {hexagonSide}px; bottom: 0; transform: translateX(50%);"
        ></div>
        <div
            class="border"
            style="width: {hexagonSide}px; bottom: 0; transform: translateX(100%) rotate(-60deg) translateX(50%);"
        ></div>
    </div>
{/if}

<style>
    .content-wrapper {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        pointer-events: auto; /* allow clicks on slot content */
        /* optionally: */
        display: flex;
        justify-content: center;
        align-items: center;
        user-select: none; /* optional */
        z-index: 1; /* above the borders if you want */
    }

    /* existing styles unchanged */
    .border {
        position: absolute;
        height: 1px;
        background: #eafafb;
        box-shadow:
            0 0 3px #eafafb,
            0 0 3px #eafafb,
            0 0 3px #eafafb;
    }

    .hexagon {
        position: absolute;
        overflow: visible;
        aspect-ratio: 1 / cos(30deg);
        background: #3498db;
        clip-path: polygon(50% -50%, 100% 50%, 50% 150%, 0 50%);
        box-sizing: border-box;
        opacity: 0.7;
        backdrop-filter: blur(15px);
        transition: transform 0.3s ease-in-out;
        &:hover {
            background: #2980b9;
            box-shadow:
                0 0 10px #2980b9,
                0 0 20px #2980b9,
                0 0 30px #2980b9,
                0 0 40px #2980b9;
        }
    }
</style>
