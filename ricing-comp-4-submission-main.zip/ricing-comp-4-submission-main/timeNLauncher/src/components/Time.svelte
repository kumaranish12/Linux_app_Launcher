<script lang="ts">
    import { onDestroy } from "svelte";
    import Grid from "./Grid.svelte";
    import { hexDigits } from "../static";
    let timeChars = getTimeChars();

    function getTimeChars() {
        return new Date()
            .toLocaleTimeString("en-US", {
                hour: "2-digit",
                minute: "2-digit",
            })
            .slice(0, 5)
            .split("");
    }

    const updateTime = () => {
        const newChars = getTimeChars();
        if (newChars.join("") !== timeChars.join("")) {
            timeChars = newChars;
        }
    };

    const interval = setInterval(updateTime, 1000);
    onDestroy(() => clearInterval(interval));
</script>

<div class="container">
    <div class="time">
        {#each timeChars as char, i (`${char}-${i}`)}
            <Grid grid={hexDigits[char]} hexagonSide={20} />
        {/each}
    </div>
    <div class="time image">
        {#each timeChars as char, i (`${char}-${i}`)}
            <Grid grid={hexDigits[char]} hexagonSide={20} />
        {/each}
    </div>
</div>

<style>
    .container {
        display: flex;
        position: absolute;
        justify-content: center;
        align-items: center;
        flex-direction: column;
        width: 100%;
        bottom: 60px;
    }
    .time {
        display: flex;
        justify-content: center;
        align-items: center;
        flex-direction: row;
        gap: 10px;
    }
    .image {
        translate: 0 20%;
        transform: rotateX(180deg);
        opacity: 0.7;
    }
</style>
