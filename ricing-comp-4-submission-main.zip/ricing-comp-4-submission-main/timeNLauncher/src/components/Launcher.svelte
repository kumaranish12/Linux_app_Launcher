<script lang="ts">
    import Grid from "./Grid.svelte";
    import type { App } from "../types";
    let apps: App[] = $state([]);
    let mat: number[][] = $state([[0]]);
    const { filter } = $props<{ filter: string }>();

    function generateMat(totalOnes: number): number[][] {
        let mat: number[][] = [];
        let cols = Math.ceil((Math.sqrt(totalOnes) * 4) / 3);
        let rows = Math.ceil((Math.sqrt(totalOnes) * 3) / 4);

        // Fill the matrix with ones and zeros
        for (let i = 0; i < rows; i++) {
            mat[i] = [];
            for (let j = 0; j < cols; j++) {
                if (totalOnes > 0) {
                    mat[i][j] = 1;
                } else {
                    mat[i][j] = 0;
                }
                totalOnes--;
            }
        }

        // If there's only one row, return as is
        if (mat.length < 2) return mat;

        // Calculate the number of ones in the first and last rows
        let onesFirstRow = mat[0].reduce((acc, val) => acc + val, 0);
        let onesLastRow = mat[mat.length - 1].reduce(
            (acc, val) => acc + val,
            0,
        );
        let total = onesFirstRow + onesLastRow;

        // Redistribute ones between the first and last rows to make them symmetric
        let balancedOnes = Math.floor(total / 2);
        let remainingOnes = total % 2;

        // Clear the first and last rows
        mat[0] = new Array(cols).fill(0);
        mat[mat.length - 1] = new Array(cols).fill(0);

        // Fill the first row with balanced ones
        let startFirst = Math.floor((cols - balancedOnes - remainingOnes) / 2);
        for (
            let j = startFirst;
            j < startFirst + balancedOnes + remainingOnes;
            j++
        ) {
            if (j < cols) mat[0][j] = 1;
        }

        // Fill the last row with balanced ones
        let startLast = Math.floor((cols - balancedOnes) / 2);
        for (let j = startLast; j < startLast + balancedOnes; j++) {
            if (j < cols) mat[mat.length - 1][j] = 1;
        }

        return mat;
    }

    window.getApps = (data: string) => {
        let t = JSON.parse(data);
        t = t.filter(
            (app: app) =>
                app.icon.endsWith(".png") ||
                app.icon.endsWith(".svg") ||
                app.icon.endsWith(".xmp"),
        );
        apps = t;
        mat = generateMat(apps.length);
        // alert(`Apps: ${apps.length} \nMatrix: ${mat.length}x${mat[0].length}`);
    };
    let updateApps = () => {
        window.weld({
            type: "manual_state_update",
            function: "getApps",
        });
    };
    updateApps();
</script>

<div class="launcher mask">
    <Grid grid={mat} hexagonSide={50} {apps} {filter} />
</div>

<style>
    .launcher {
        position: absolute;
        height: 100%;
        width: 100%;
        display: flex;
        justify-content: center;
        align-items: center;
    }
</style>
