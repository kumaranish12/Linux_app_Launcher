[![Watch the video](https://img.youtube.com/vi/aCsIvjVcDmY/hqdefault.jpg)](https://youtu.be/aCsIvjVcDmY)

🎥 **Submission for the 4th Hyprland Ricing Competition**

This setup showcases a dynamic and customizable widget system powered by [WeLD](https://github.com/fjueic/WeLD), a framework that leverages web technologies for creating interactive widget on Wayland.
