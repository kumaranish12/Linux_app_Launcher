<script lang="ts">
    function close() {
        window.weld({
            name: window.name,
            type: "close",
        });
        window.toggle = () => {
            alert("toggle");
        };
    }

    const japaneseChars =
        "アイウエオカキクケコサシスセソタチツテトナニヌネノハヒフヘホ".split(
            "",
        );

    let password = $state<string>("");
    let displayedPassword = $state<string>("");
    let hovered = $state(false);
    let isAuthenticating = $state(false);
    let animationClass = $state<string>("");

    window.auth = (data) => {
        isAuthenticating = false;

        if (data === "true") {
            animationClass = "auth-success";
            setTimeout(() => {
                close();
            }, 1000);
        } else if (data === "false") {
            animationClass = "auth-fail";
            setTimeout(() => {
                password = "";
                displayedPassword = "";
                animationClass = "";
            }, 1000);
        }
    };

    document.addEventListener("keydown", (e) => {
        if (e.key === "Escape") close();

        if (e.key === "Enter") {
            if (password.length > 0) {
                isAuthenticating = true;
                animationClass = "auth-loading";
                window.weld({
                    type: "manual_state_update",
                    function: "auth",
                    args: {
                        password: password,
                    },
                });
            }
        }

        if (e.key === "Backspace") {
            password = password.slice(0, -1);
            displayedPassword = displayedPassword.slice(0, -1);
        } else if (
            "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ".includes(
                e.key,
            )
        ) {
            isAuthenticating = false;
            animationClass = "";
            password += e.key;
            displayedPassword +=
                japaneseChars[Math.floor(Math.random() * japaneseChars.length)];
        }
    });

    function getRandomTransform() {
        return {
            x: Math.random() * 600 - 300, // Wider range for animation
            y: Math.random() * 600 - 300,
            scale: Math.random() * 1.75 + 0.25,
        };
    }
</script>

<link
    href="https://fonts.googleapis.com/css2?family=Noto+Sans+JP:wght@500&display=swap"
    rel="stylesheet"
/>

<div
    class="container"
    on:mouseenter={() => (hovered = true)}
    on:mouseleave={() => (hovered = false)}
>
    <div class="japanese-chars {animationClass}">
        {#each displayedPassword.split("") as char, i}
            <span
                class="char"
                style={isAuthenticating ||
                hovered ||
                animationClass === "auth-success" ||
                animationClass === "auth-fail"
                    ? `
                        --x: ${getRandomTransform().x}px;
                        --y: ${getRandomTransform().y}px;
                        --scale: ${getRandomTransform().scale};
                    `
                    : ""}
            >
                {char}
            </span>
        {/each}
    </div>
</div>

<!-- <button class="close-button" on:click={close} aria-label="Close" title="Close"> -->
<!--     Close -->
<!-- </button> -->

<style>
    .container {
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background: transparent;
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .japanese-chars {
        display: flex;
        gap: 10px;
        pointer-events: none;
    }

    .char {
        display: inline-block;
        transform: translate(-50%, -50%) perspective(800px) rotateY(15deg)
            translate(var(--x, 0), var(--y, 0)) scale(var(--scale, 1));
        font-size: 80px;
        color: rgba(41, 128, 185, 0.8);
        font-family: "Noto Sans JP", sans-serif;
        white-space: nowrap;
        text-shadow: 0 0 10px rgba(41, 128, 185, 0.4);
        letter-spacing: 10px;
        user-select: none;
        opacity: 1;
        transition:
            transform 0.5s ease,
            opacity 0.5s ease;
    }

    .close-button {
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 100;
    }

    /* ✨ Authenticating pulse */
    .auth-loading .char {
        animation: pulse 1s infinite;
    }

    @keyframes pulse {
        0%,
        100% {
            filter: brightness(1);
        }
        50% {
            filter: brightness(1.5);
        }
    }

    /* ❌ Fail - fly outward + fade + red */
    .auth-fail .char {
        color: rgba(231, 76, 60, 0.9);
        text-shadow: 0 0 10px rgba(231, 76, 60, 0.6);
        animation: flyFadeOut 1s forwards;
    }

    /* ✅ Success - fly outward + fade + blue */
    .auth-success .char {
        color: rgba(41, 128, 185, 0.8);
        text-shadow: 0 0 10px rgba(41, 128, 185, 0.5);
        animation: flyFadeOut 1s forwards;
    }

    @keyframes flyFadeOut {
        0% {
            opacity: 1;
            /* transform: scale(1) translate(0, 0); */
        }
        100% {
            opacity: 0;
            /* transform: scale(2) translate(var(--x), var(--y)); */
        }
    }
</style>
